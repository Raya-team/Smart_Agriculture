@extends('errors::minimal')

@section('title', __('غیر مجاز'))
@section('code', '401')
@section('message', __('!شما اجازه دسترسی به این صفحه را ندارید'))
