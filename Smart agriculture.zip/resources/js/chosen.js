import 'chosen-js';

$(".chosen-select").chosen({
    rtl: true,
    no_results_text: "نتیجه ای برای عبارت وارد شده یافت نشد : ",
});
